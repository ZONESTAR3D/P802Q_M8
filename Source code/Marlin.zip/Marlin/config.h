/**************************************************************************
ZONESTAR 3D PRINTER DIY KIT Firmware Configuaration
http://www.zonestar3d.com/
**************************************************************************/
#ifndef __CONFIG_H__
#define __CONFIG_H__

#include "modellist.h"

/*********************************************************************************************************
//Choose one printer model from the model list
//about the model list, please see the "modellist.h" file
*********************************************************************************************************/
#define	MODEL_NUMBER		M8R2
/*********************************************************************************************************/
//common setting for all of model
//Some of the settings may be covered behind
/*********************************************************************************************************/
#define	STRING_CONFIG_H_AUTHOR	"(Hally@ZONESTAR)"
#define	EEPROM_VERSION			"V55"
#define	SHOW_ZONESTAR_LOGO
#define	INDIVIDUAL_AXIS_HOMING_MENU
#define SDCARD_SORT_ALPHA
#define ARC_SUPPORT
#define AUTOTEMP
#define	ADJUST_ATUO_FAN_SPEED
#define	EXTRUDER_AUTO_FAN_SPEED	255
#define ADJUST_MIN_POS_MENU
#define LCD_INFO_MENU

#define	X_STEPS_PERMM		80
#define	Y_STEPS_PERMM		80
#define	Z_STEPS_PERMM		400
#define	E_STEPS_PERMM		85

#define	MAX_ACC_X			2000
#define	MAX_ACC_Y			800
#define	MAX_ACC_Z			100

/**
 * LCD LANGUAGE
 *
 * Select the language to display on the LCD. These languages are available:
 *
 *    en, an, bg, ca, cn, cz, cz_utf8, de, el, el-gr, es, eu, fi, fr, fr_utf8, gl,
 *    hr, it, kana, kana_utf8, nl, pl, pt, pt_utf8, pt-br, pt-br_utf8, ru, sk_utf8,
 *    tr, uk, zh_CN, zh_TW, test
 *
 * :{ 'en':'English', 'an':'Aragonese', 'bg':'Bulgarian', 'ca':'Catalan', 'cn':'Chinese', 'cz':'Czech', 
 	'cz_utf8':'Czech (UTF8)', 'de':'German', 'el':'Greek', 'el-gr':'Greek (Greece)', 'es':'Spanish', 'eu':'Basque-Euskera', 
 	'fi':'Finnish', 'fr':'French', 'fr_utf8':'French (UTF8)', 'gl':'Galician', 'hr':'Croatian', 'it':'Italian', 
 	'kana':'Japanese', 'kana_utf8':'Japanese (UTF8)', 'nl':'Dutch', 'pl':'Polish', 'pt':'Portuguese', 'pt-br':'Portuguese (Brazilian)', 
 	'pt-br_utf8':'Portuguese (Brazilian UTF8)', 'pt_utf8':'Portuguese (UTF8)', 'ru':'Russian', 'sk_utf8':'Slovak (UTF8)', 'tr':'Turkish', 
 	'uk':'Ukrainian', 'zh_CN':'Chinese (Simplified)', 'zh_TW':'Chinese (Taiwan)', test':'TEST' }
 */
#define LCD_LANGUAGE en

/*********************************************************************************************************/
//END of common setting
/*********************************************************************************************************/


/*********************************************************************************************************/
//Setting for different model
//Prusa i3, Full Acrylic frame, acrylic hotend
//P802C Serial
/*********************************************************************************************************/
#if (MODEL_NUMBER == P802Q_MELZI_5KEY)
//P802Q 1st version, Single extruder,  LCD2004 and 5Key keypad, Melzi control board
#define CUSTOM_MACHINE_NAME 		"P802Q_MELZI_5K"
#define	STRING_FIRMWARE_VERSION		"V1.3"
#define MOTHERBOARD 				BOARD_MELZI_ZONESTAR

#define	EXTRUDERS					1
#define	BED_SIZE 					220
#define	MAX_PRINT_HEIGHT			230
#define X_MIN_POS 					-10
#define Y_MIN_POS 					-5
#define ZONESTAR_LCD2004_ADCKEY
#define	PTFE_TUBE_LENGTH			500
#define	AUTO_BED_LEVELING_LINEAR
#define LEFT_PROBE_BED_POSITION 	30
#define RIGHT_PROBE_BED_POSITION 	190
#define FRONT_PROBE_BED_POSITION 	10
#define BACK_PROBE_BED_POSITION 	210

#elif (MODEL_NUMBER == P802QS_5KEY)	
//P802Q 2nd version, Single extruder,  LCD2004 and 5Key keypad, ZRIB control board
#define MOTHERBOARD 				BOARD_ZRIB
//#define	BLTOUCH

#ifdef BLTOUCH
#define	X_PROBE_OFFSET_FROM_EXTRUDER	20
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#define CUSTOM_MACHINE_NAME 		"QS_5KEY_BLTOUCH"
#define	STRING_FIRMWARE_VERSION		"V1.0"
#else
#define	X_PROBE_OFFSET_FROM_EXTRUDER  30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER  0
#define CUSTOM_MACHINE_NAME 		"QS_5KEY"
#define	STRING_FIRMWARE_VERSION		"V2.0"
#endif

#define	EXTRUDERS					1
#define	BED_SIZE 					220
#define	MAX_PRINT_HEIGHT			240
#define X_MIN_POS 					-10
#define Y_MIN_POS 					-5
#define ZONESTAR_LCD2004_ADCKEY
#define LEFT_PROBE_BED_POSITION 	30
#define RIGHT_PROBE_BED_POSITION 	190
#define FRONT_PROBE_BED_POSITION 	10
#define BACK_PROBE_BED_POSITION 	210
#define AUTO_BED_LEVELING_LINEAR
#define	PTFE_TUBE_LENGTH			500

#elif (MODEL_NUMBER == P802QR2_5KEY)
//P802Q 2nd version, dual extruder,  LCD2004 and 5Key keypad, ZRIB control board
#define MOTHERBOARD 				BOARD_ZRIB
#define	BLTOUCH

#ifdef BLTOUCH
#define	X_PROBE_OFFSET_FROM_EXTRUDER	20
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#define CUSTOM_MACHINE_NAME 			"QR2_5KEY_BLTOUCH"
#define	STRING_FIRMWARE_VERSION			"V1.0"
#define	_FIRMWARE_RELEASE_DATE_			"2019-08-28"
#else
#define	X_PROBE_OFFSET_FROM_EXTRUDER  	30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER  	0
#define CUSTOM_MACHINE_NAME 			"QR2_5KEY"
#define	STRING_FIRMWARE_VERSION			"V3.1"
#endif

#define	EXTRUDERS						2
#define	BED_SIZE 						220
#define	MAX_PRINT_HEIGHT				240
#define X_MIN_POS 						-10
#define Y_MIN_POS 						-5
#define ZONESTAR_LCD2004_ADCKEY
#define LEFT_PROBE_BED_POSITION 		30
#define RIGHT_PROBE_BED_POSITION 		190
#define FRONT_PROBE_BED_POSITION 		10
#define BACK_PROBE_BED_POSITION 		210
#define AUTO_BED_LEVELING_LINEAR
#define	PTFE_TUBE_LENGTH				500

#elif (MODEL_NUMBER == P802QM2_5KEY)
//P802Q 2nd version, 2-IN-1-OUT Mixing extruder,  LCD2004 and 5Key keypad, ZRIB control board
#define MOTHERBOARD 				BOARD_ZRIB
#ifdef BLTOUCH
#define	X_PROBE_OFFSET_FROM_EXTRUDER	20
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#define CUSTOM_MACHINE_NAME 			"QM2_5KEY_BLTOUCH"
#define	STRING_FIRMWARE_VERSION			"V1.0"
#define	_FIRMWARE_RELEASE_DATE_			"2019-03-01"
#else
#define	X_PROBE_OFFSET_FROM_EXTRUDER  	30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER  	0
#define CUSTOM_MACHINE_NAME 			"QM2_5KEY"
#define	STRING_FIRMWARE_VERSION			"V3.0"
#define	_FIRMWARE_RELEASE_DATE_			"2018-10-01"
#endif

#define	EXTRUDERS					1
#define MIXING_EXTRUDER
#define HEATERS_PARALLEL

#define	BED_SIZE 						220
#define	MAX_PRINT_HEIGHT				240
#define X_MIN_POS 						-10
#define Y_MIN_POS 						-5
#define ZONESTAR_LCD2004_ADCKEY
#define LEFT_PROBE_BED_POSITION 		30
#define RIGHT_PROBE_BED_POSITION 		190
#define FRONT_PROBE_BED_POSITION 		10
#define BACK_PROBE_BED_POSITION 		210
#define AUTO_BED_LEVELING_LINEAR
#define	PTFE_TUBE_LENGTH				500

#elif ((MODEL_NUMBER == P802QS_KNOB) || (MODEL_NUMBER == M8S))
//P802Q 3nd version, Single extruder,  LCD2004 and knob keypad, ZRIB control board	
#define MOTHERBOARD 				BOARD_ZRIB
//#define	BLTOUCH

#ifdef BLTOUCH
#define	X_PROBE_OFFSET_FROM_EXTRUDER	20
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#define CUSTOM_MACHINE_NAME 			"M8S_BLTOUCH"
#define	STRING_FIRMWARE_VERSION			"V1.0"
#define	_FIRMWARE_RELEASE_DATE_			"2019-03-01"
#else
#define	X_PROBE_OFFSET_FROM_EXTRUDER  	30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER  	0
#define CUSTOM_MACHINE_NAME 			"M8S"
#define	STRING_FIRMWARE_VERSION			"V3.0"
#define	_FIRMWARE_RELEASE_DATE_			"2019-02-13"
#endif

#define	EXTRUDERS					1
#define	BED_SIZE 					220
#define	MAX_PRINT_HEIGHT			240
#define X_MIN_POS 					-10
#define Y_MIN_POS 					-5
#define ZONESTAR_LCD2004_KNOB

#define AUTO_BED_LEVELING_LINEAR
#define LEFT_PROBE_BED_POSITION 	30
#define RIGHT_PROBE_BED_POSITION 	190
#define FRONT_PROBE_BED_POSITION 	5
#define BACK_PROBE_BED_POSITION 	215

#define	PTFE_TUBE_LENGTH			500


#elif (MODEL_NUMBER == P802QR2_KNOB)	
//P802Q 3nd version, dual extruder,  LCD2004 and knob keypad, ZRIB control board
#define MOTHERBOARD 					BOARD_ZRIB
//#define	BLTOUCH
//#define	DM_TMC2208

#ifdef BLTOUCH
#define	X_PROBE_OFFSET_FROM_EXTRUDER	20
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#define CUSTOM_MACHINE_NAME 			"QR2_KNOB_BLTOUCH"
#define	STRING_FIRMWARE_VERSION			"V1.1.0"
#define	_FIRMWARE_RELEASE_DATE_			"2020-07-23"
#elif defined(DM_TMC2208)
#define	X_PROBE_OFFSET_FROM_EXTRUDER  	30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER  	0
#define CUSTOM_MACHINE_NAME 			"QR2_KNOB_TMC2208"
#define	STRING_FIRMWARE_VERSION			"V2.0"
#define	_FIRMWARE_RELEASE_DATE_			"2020-03-03"
#else
#define	X_PROBE_OFFSET_FROM_EXTRUDER  	30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER  	0
#define CUSTOM_MACHINE_NAME 			"QR2_KNOB"
#define	STRING_FIRMWARE_VERSION			"V3.1.0"
#define	_FIRMWARE_RELEASE_DATE_			"2020-07-23"
#endif

#define	EXTRUDERS						2
#define	BED_SIZE 						220
#define	MAX_PRINT_HEIGHT				240
#define X_MIN_POS 						-10
#define Y_MIN_POS 						-5
#define ZONESTAR_LCD2004_KNOB
#define LEFT_PROBE_BED_POSITION 		30
#define RIGHT_PROBE_BED_POSITION 		190
#define FRONT_PROBE_BED_POSITION 		5
#define BACK_PROBE_BED_POSITION 		215
#define AUTO_BED_LEVELING_LINEAR
#define	PTFE_TUBE_LENGTH				500

#ifdef DM_TMC2208
#define INVERT_X_DIR 					false
#define INVERT_Y_DIR 					false
#define INVERT_Z_DIR 					true
#define	INVERT_E0_DIR					false
#define	INVERT_E1_DIR					false
#else
#define INVERT_X_DIR 					true
#define INVERT_Y_DIR 					true
#define INVERT_Z_DIR 					false
#define	INVERT_E0_DIR					true
#define	INVERT_E1_DIR					true
#endif

#elif (MODEL_NUMBER == P802QR2_LCD12864)	
//P802QR2, dual extruder,  LCD128x64 and knob keypad, ZRIB control board
#define MOTHERBOARD 				BOARD_ZRIB
#ifdef BLTOUCH
#define	X_PROBE_OFFSET_FROM_EXTRUDER	20
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#define CUSTOM_MACHINE_NAME 			"QR2_LCD12864_BLTOUCH"
#define	STRING_FIRMWARE_VERSION			"V1.0"
#define	_FIRMWARE_RELEASE_DATE_			"2019-03-01"
#else
#define	X_PROBE_OFFSET_FROM_EXTRUDER  	30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER  	0
#define CUSTOM_MACHINE_NAME 			"QR2_LCD12864"
#define	STRING_FIRMWARE_VERSION			"V2.0"
#define	_FIRMWARE_RELEASE_DATE_			"2018-10-01"
#endif

#define	EXTRUDERS					2
#define	BED_SIZE 					220
#define	MAX_PRINT_HEIGHT			240
#define X_MIN_POS 					-10
#define Y_MIN_POS 					-5
#define REPRAP_DISCOUNT_FULL_GRAPHIC_SMART_CONTROLLER
#define LEFT_PROBE_BED_POSITION 	30
#define RIGHT_PROBE_BED_POSITION 	190
#define FRONT_PROBE_BED_POSITION 	5
#define BACK_PROBE_BED_POSITION 	215
#define AUTO_BED_LEVELING_LINEAR
#define	PTFE_TUBE_LENGTH			500

#define INVERT_X_DIR 	true
#define INVERT_Y_DIR 	true
#define INVERT_Z_DIR 	false


#elif (MODEL_NUMBER == P802QR2_MINI12864)	
//P802QR2, dual extruder,  LCD128x64 and knob keypad, ZRIB control board
#define CUSTOM_MACHINE_NAME 		"QR2_Mini12864"
#define	STRING_FIRMWARE_VERSION		"V1.0"
#define MOTHERBOARD 				BOARD_ZRIB

#define	EXTRUDERS					2
#define	BED_SIZE 					220
#define	MAX_PRINT_HEIGHT			240
#define X_MIN_POS 					-10
#define Y_MIN_POS 					-5
#define MKS_MINI_12864
#define LEFT_PROBE_BED_POSITION 	30
#define RIGHT_PROBE_BED_POSITION 	190
#define FRONT_PROBE_BED_POSITION 	5
#define BACK_PROBE_BED_POSITION 	215
#define AUTO_BED_LEVELING_LINEAR
#define	PTFE_TUBE_LENGTH			500

#elif ((MODEL_NUMBER == P802QM2_KNOB) || (MODEL_NUMBER == M8R2))
//P802Q 3nd version, 2-IN-1-OUT Mixing extruder,  LCD2004 and knob keypad, ZRIB control board
#define MOTHERBOARD 				BOARD_ZRIB
//#define BLTOUCH
//#define	SWAP_XM_E2M
#ifdef BLTOUCH
#define	X_PROBE_OFFSET_FROM_EXTRUDER	20
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#define CUSTOM_MACHINE_NAME 			"M8R2_BLTOUCH"
#define	STRING_FIRMWARE_VERSION			"V2.0.1"
#define	_FIRMWARE_RELEASE_DATE_			"2020-07-24"
#else
#define	X_PROBE_OFFSET_FROM_EXTRUDER	30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#ifdef SWAP_XM_E2M
#define CUSTOM_MACHINE_NAME 			"M8R2_XM_2_W2M"
#else
#define CUSTOM_MACHINE_NAME 			"M8R2"
#endif
#define	STRING_FIRMWARE_VERSION			"V3.3.0"
#define	_FIRMWARE_RELEASE_DATE_			"2020-07-24"
#endif

#define	EXTRUDERS					1
#define MIXING_EXTRUDER
#define HEATERS_PARALLEL
#define	BED_SIZE 					220
#define	MAX_PRINT_HEIGHT			240
#define X_MIN_POS 					-10
#define Y_MIN_POS 					-5
#define ZONESTAR_LCD2004_KNOB

#define INVERT_X_DIR 	true
#define INVERT_Y_DIR 	true
#define INVERT_Z_DIR 	false

#define AUTO_BED_LEVELING_LINEAR
#define LEFT_PROBE_BED_POSITION 	30
#define RIGHT_PROBE_BED_POSITION 	200
#define FRONT_PROBE_BED_POSITION 	30
#define BACK_PROBE_BED_POSITION 	200
#define	PTFE_TUBE_LENGTH			500

#elif(MODEL_NUMBER == M8R2S)
//P802Q 3nd version, 2-IN-2-OUT extruder,  LCD2004 and knob keypad, ZRIB control board
#define MOTHERBOARD 				BOARD_ZRIB
//#define BLTOUCH
//#define	SWAP_XM_E2M
#ifdef BLTOUCH
#define	X_PROBE_OFFSET_FROM_EXTRUDER	20
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#define CUSTOM_MACHINE_NAME 			"M8R2S_BLTOUCH"
#define	STRING_FIRMWARE_VERSION			"V1.0"
#define	_FIRMWARE_RELEASE_DATE_			"2019-08-13"
#else
#define	X_PROBE_OFFSET_FROM_EXTRUDER	30
#define	Y_PROBE_OFFSET_FROM_EXTRUDER	0
#ifdef SWAP_XM_E2M
#define CUSTOM_MACHINE_NAME 			"M8R2S_XM_2_W2M"
#else
#define CUSTOM_MACHINE_NAME 			"M8R2S"
#endif
#define	STRING_FIRMWARE_VERSION			"V1.0"
#define	_FIRMWARE_RELEASE_DATE_			"2019-08-13"
#endif

#define	EXTRUDERS					2
#define	SINGLENOZZLE
#define HEATERS_PARALLEL
#define	BED_SIZE 					220
#define	MAX_PRINT_HEIGHT			240
#define X_MIN_POS 					-10
#define Y_MIN_POS 					-5
#define ZONESTAR_LCD2004_KNOB

#define INVERT_X_DIR 				true
#define INVERT_Y_DIR 				true
#define INVERT_Z_DIR 				false

#define AUTO_BED_LEVELING_LINEAR
#define LEFT_PROBE_BED_POSITION 	30
#define RIGHT_PROBE_BED_POSITION 	200
#define FRONT_PROBE_BED_POSITION 	30
#define BACK_PROBE_BED_POSITION 	200
#define	PTFE_TUBE_LENGTH			500
#endif
/*********************************************************************************************************
Setting for different model
*********************************************************************************************************/



/*********************************************************************************************************
other settings
*********************************************************************************************************/

#endif // __CONFIG_H__
