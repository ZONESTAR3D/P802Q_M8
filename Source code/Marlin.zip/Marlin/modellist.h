#ifndef __MODEL_LIST_H__
#define	__MODEL_LIST_H__
/*********************************************************************************************************/
//							Model list
/*********************************************************************************************************/
#define	P802Q_MELZI_5KEY	30	//P802Q 1st version, Single extruder,  LCD2004 and 5Key keypad, ZRIB control board
#define	P802QS_5KEY			31	//P802Q 2nd version, Single extruder,  LCD2004 and 5Key keypad, ZRIB control board
#define	P802QR2_5KEY		32	//P802Q 2nd version, dual extruder,  LCD2004 and 5Key keypad, ZRIB control board
#define	P802QM2_5KEY		33	//P802Q 2nd version, 2-IN-1-OUT Mixing extruder,  LCD2004 and 5Key keypad, ZRIB control board
#define	P802QS_KNOB			34	//P802Q 3nd version, Single extruder,  LCD2004 and knob keypad, ZRIB control board
#define	M8S					34
#define	P802QR2_KNOB		35	//P802Q 3nd version, dual extruder,  LCD2004 and knob keypad, ZRIB control board
#define	P802QM2_KNOB		36	//P802Q 3nd version, 2-IN-1-OUT Mixing extruder,  LCD2004 and knob keypad, ZRIB control board
#define	M8R2				36
#define	M8R2S				320
#define	P802QR2_LCD12864	37	//P802QR2, dual extruder,  LCD128x64 and knob keypad, ZRIB control board
#define	P802QR2_MINI12864	38	//P802QR2, dual extruder,  MKS Mini LCD128x64 and knob keypad, ZRIB control board
/*********************************************************************************************************/
//							END of Model list 
/*********************************************************************************************************/
#endif
